/***********************************************************************
*  PROGRAM:     CSCI 480 Project 4
*  AUTHOR:      Eriq Walker
*  ZID:         Z1908120
*  DUE DATE:    02/05/2022
*  DESCRIPTION: This program uses first come first serve for process
                management.
***********************************************************************/

#include "process.h"

process::process() {
    //initialize variables to '0'
    processName = "";
    
    processID   = 0;
    arrivalTime = 0;
    processWait = 0;
    CPUTimer    = 0;
    ITimer      = 0;
    OTimer      = 0;
    CPUTotal    = 0;
    ITotal      = 0;
    OTotal      = 0;
    CPUCount    = 0;
    ICount      = 0;
    OCount      = 0;
    
    history = std::vector<std::pair<std::string, int>>();
}

//to string function
std::string process::toString() {
    std::stringstream ss;
    ss << processID;
    return ss.str();
}

//type getter
std::string process::getType() { return history[pos].first; }

//total getter
int process::getTotal() { return history[pos].second; }