/***********************************************************************
*  PROGRAM:     CSCI 480 Project 4
*  AUTHOR:      Eriq Walker
*  ZID:         Z1908120
*  DUE DATE:    02/05/2022
*  DESCRIPTION: This program uses first come first serve for process
                management.
***********************************************************************/

#include <deque>
#include "process.h"

//constants
#define MAX_TIME    500
#define IN_USE        5
#define HOW_OFTEN    25
#define QUEUE_SIZE   20
#define VECTOR_SIZE  10

class processManager {
    public:
        processManager();
        ~processManager();
        void loadReadyQueue();
        void run();
        void newProcess(int, std::string, std::string);
        bool isActive();
        int getCPUTimer();
        std::string toString();
        std::string printEnd();
        
    private:
        int CPUTimer = 0, idleTimer = 0;
        bool alreadyIdled = false, firstPass = true;
        process *active = nullptr, *iActive = nullptr, *oActive = nullptr;
        
        std::deque<process*> entry, ready, input, output, completed;
        
        std::string printQueue(std::deque<process*>, std::string);
        int getTotal();
};