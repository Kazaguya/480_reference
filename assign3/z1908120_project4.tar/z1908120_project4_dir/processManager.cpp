/***********************************************************************
*  PROGRAM:     CSCI 480 Project 4
*  AUTHOR:      Eriq Walker
*  ZID:         Z1908120
*  DUE DATE:    02/05/2022
*  DESCRIPTION: This program uses first come first serve for process
                management.
***********************************************************************/

#include "processManager.h"

//constructor
processManager::processManager(){}

//destructor
processManager::~processManager(){}

//'main' function for this program.
//while this is not the actual main, this is where most of the
//work actually happens
void processManager::run() {
    //make sure queues are loaded
    loadReadyQueue();
    
    //if inactive and not the first pass
    if (!active && !firstPass) {
        //if ready has at least one item in it
        if (ready.size() > 0) {
            //take that process out of the queue
            process* p = ready[0];
            
            p->CPUTimer = 0;
            p->ITimer   = 0;
            p->OTimer   = 0;
            
            //set active process to the one just taken from the queue
            active = p;
            
            //actually remove it from queue
            ready.pop_front();
        } else {
            //if we haven't already told the user that the program is
            //idling, then do so
            if(!alreadyIdled) {
                std::cout << "\nAt time " << CPUTimer 
                          << ", Active is 0, so we have idle time for a while\n\n";
                //set to true so you don't print this again until more work is done
                alreadyIdled = true;
            }
            //incremener idle time since no work was done
            idleTimer++;
        }
    }
    
    //if there is something in active
    if (active) {
        //increment counters
        active->CPUTimer++;
        active->CPUTotal++;
        
        //if the current timer is greater than or equal to the total
        //time it takes to complete the current task
        if (active->CPUTimer >= active->getTotal()) {
            //move to next task in the process
            active->pos++;
            active->CPUCount++;
            //reset timer
            active->CPUTimer = 0;
            
            //if input task
            if      (active->getType() == "I") input.push_back(active);
            //if output task
            else if (active->getType() == "O") output.push_back(active);
            //if null task
            else if (active->getType() == "N") {
                //set endtime and move to completed queue
                active->endTime = CPUTimer;
                completed.push_back(active);
                
                //string variables for output
                std::string cpuburst = active->CPUCount == 1 ? "burst " : "bursts";
                std::string iburst   = active->ICount   == 1 ? "burst " : "bursts";
                std::string oburst   = active->OCount   == 1 ? "burst " : "bursts";
                
                //print output
                std::cout << "\nProcess " << active->processID << " has ended.\n";
                std::cout << "Name:  " << active->processName;
                std::cout << "\nStarted at time " << active->startTime 
                          << " and ended at time " << active->endTime;
                std::cout << "\nTotal CPU time =  " << active->CPUTotal 
                          << " in " << active->CPUCount << " CPU " << cpuburst;
                std::cout << "\nTotal Input time =  " << active->ITotal 
                          << " in " << active->ICount << " Input " << iburst;
                std::cout << "\nTotal Output time =  " << active->OTotal << " in "
                          << active->OCount << " Output " << oburst;
                std::cout << "\nTime spent in waiting:  " << active->processWait 
                          << std::endl << std::endl;
            }
            
            //reset active and idled
            active = nullptr;
            alreadyIdled = false;
        }
    }
    
    //if no active input task and not first pass
    if (!iActive && !firstPass) {
        //if input has item take it out and make it active
        if (input.size() > 0) {
            process* p = input[0];
            
            p->CPUTimer = 0;
            p->ITimer   = 0;
            p->OTimer   = 0;
            
            iActive = p;
            input.pop_front();
        }
    }
    
    //if active input
    if (iActive) {
        //increment counters
        iActive->ITimer++;
        iActive->ITotal++;
        
        //if task finished move to next one
        if (iActive->ITimer >= iActive->getTotal()) {
            iActive->pos++;
            iActive->ICount++;
            iActive->ITimer = 0;
            
            ready.push_back(iActive);
            iActive = nullptr;
        }
    }
    
    //if no active output task and not first pass
    if (!oActive && !firstPass) {
        //if output has item take it out and make it active
        if (output.size() > 0) {
            process* p = output[0];
            
            p->CPUTimer = 0;
            p->ITimer = 0;
            p->OTimer = 0;
            
            oActive = p;
            output.pop_front();
        }
    }
    
    //if active output
    if (oActive) {
        //increment counters
        oActive->OTimer++;
        oActive->OTotal++;
        
        //if task finished move to next one
        if (oActive->OTimer >= oActive->getTotal()) {
            oActive->pos++;
            oActive->OCount++;
            oActive->OTimer = 0;
            
            ready.push_back(oActive);
            oActive = nullptr;
        }
    }
    
    //add wait time for any processes waiting in queues
    for (process *p: ready) {
         if (!firstPass && !alreadyIdled) p->processWait++;
    }
    
    for (process *p: input) {
        if (!firstPass && !alreadyIdled) p->processWait++;
    }
    
    for (process *p: output) {
        if (!firstPass && !alreadyIdled) p->processWait++;
    }
    
    //if appropriate to print, do so
    if (CPUTimer%HOW_OFTEN == 0) {
        std::cout << "\nStatus at time " << CPUTimer << "\n";
        std::cout << toString() << std::endl;
    }
    
    //if the 'cpu' is active, increase the counter
    if (isActive()) {
        CPUTimer++;
    }
    
    //let the system know it's completed it's first pass
    firstPass = false;
}

//process for creating new process
void processManager::newProcess(int id, std::string s1, std::string s2) {
    //create new empty process
    process* p = new process();
    
    //string stream helper
    std::stringstream ss(s1);
    //extract name
    ss >> p->processName;
    //if appropriate, exit early
    if(p->processName == "STOPHERE") return;
    //set ID
    p->processID = id;
    //extract the arrival time as int
    std::string s = "";
    ss >> s;
    p->arrivalTime = stoi(s);
    
    //stringstream helper
    std::stringstream ss2(s2);
    //while there is more info for this process
    //extract task info
    while(ss2.rdbuf()->in_avail() != 0) {
        std::string type, length_string;
        int length_int;
        ss2 >> type;
        ss2 >> length_string;
        
        if(type != "" and length_string != ""){
            length_int = std::stoi(length_string);
            p->history.push_back(make_pair(type, length_int));
        }
    }
    
    entry.push_back(p);
}

//function for loading the queue
void processManager::loadReadyQueue() {
    //if inactive and there is room
    //take the nect process and put it into ready queue
    //and print saying you've done so
    if (!active && ready.size() <= IN_USE) {
        for (long unsigned int i = 0; i < entry.size(); i++) {
            if (entry[i]->arrivalTime <= CPUTimer &&  getTotal() <= IN_USE) {
                std::cout << "\nProcess " << entry[i]->processID 
                          << " moved from the Entry Queue into the Ready Queue at time " 
                          <<  CPUTimer << std::endl << std::endl;
                     
                entry[i]->startTime = CPUTimer;
                ready.push_back(entry[i]);
                entry.erase(entry.begin()+i);
                i-=2;
            }
        }
    }
}

//function to see if something is active or not
bool processManager::isActive() {
    bool qHolds = false;
    if ( entry.size() > 0 || ready.size() > 0 ||
        output.size() > 0 || input.size() > 0) qHolds = true;

    bool pActive = false; 
    if (active || iActive || oActive) pActive = true;
    
    if (CPUTimer < MAX_TIME && (qHolds || pActive)) return true;
    
    return false;
}

//to string function for the manager
std::string processManager::toString() {
    std::stringstream ss;
    
    ss << "Active is ";
    ss << (active ? active->toString() : "0");
    ss << std::endl;
    
    ss << "IActive is ";
    ss << (iActive ? iActive->toString() : "0");
    ss << std::endl;
    
    ss << "OActive is ";
    ss << (oActive ? oActive->toString() : "0");
    ss << std::endl;
    
    ss << "Contents of the Entry Queue:\n";
    if (entry.size() > 0) {
        for (process* p: entry) {
            ss << p->toString() << "    ";
        }
    } else {
        ss << "(Empty)";
    }
    
    
    ss << printQueue(ready, "Ready");
    ss << printQueue(input, "Input");
    ss << printQueue(output, "Output");
    ss << std::endl;
    return ss.str();
}

std::string processManager::printEnd() {
    std::stringstream ss;
    double avg = 0;
    for (process *p: completed) {
        avg+=p->idleTime;
    }
    avg /= completed.size();
    ss << "\nThe run has ended\n";
    ss << "The final value of the timer was: "    << CPUTimer;
    ss << "\nThe amount of time spent idle was: " << idleTimer;
    ss << "\nNumber of terminated processes = "   << completed.size();
    ss << "\nAverage waiting time for all terminated processes = " << avg;
    ss << std::endl;
    ss << toString();
       
    return ss.str();
}

//helper function to make printing the queues easier
std::string processManager::printQueue(std::deque<process*> q, std::string s) {
    std::stringstream ss;
    
    ss << "\nContents of the " << s << " Queue:\n";
    if (q.size() > 0) {
        for (process* p : q) {
            ss << p->toString() << "    ";
        }
    } else ss << "(Empty)";
    
    return ss.str();
}

//getter for cputimer
int processManager::getCPUTimer() { return CPUTimer; }

//getter for total
int processManager::getTotal() {
    int total = 0;
    if (active)  total++;
    if (iActive) total++;
    if (oActive) total++;
    total += ready.size();
    total += input.size();
    total += output.size();
    
    return total;
}