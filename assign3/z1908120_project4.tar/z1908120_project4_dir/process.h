/***********************************************************************
*  PROGRAM:     CSCI 480 Project 4
*  AUTHOR:      Eriq Walker
*  ZID:         Z1908120
*  DUE DATE:    02/05/2022
*  DESCRIPTION: This program uses first come first serve for process
                management.
***********************************************************************/

#include <string>
#include <vector>
#include <sstream>
#include <iostream>

class process {
    public: 
        process();
        
        std::string processName;
        
        int processID;
        int arrivalTime;
        int processWait;
        int CPUTimer;
        int ITimer;
        int OTimer;
        int CPUTotal;
        int ITotal;
        int OTotal;
        int CPUCount;
        int ICount;
        int OCount;
        
        int startTime = 0;
        int endTime   = 0;
        int idleTime  = 0;
        int pos       = 0;
        
        std::vector<std::pair<std::string, int>> history;
        
        std::string toString();
        std::string getType();
        
        int getTotal();
};