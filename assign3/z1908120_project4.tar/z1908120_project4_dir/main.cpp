/***********************************************************************
*  PROGRAM:     CSCI 480 Project 4
*  AUTHOR:      Eriq Walker
*  ZID:         Z1908120
*  DUE DATE:    02/05/2022
*  DESCRIPTION: This program uses first come first serve for process
                management.
***********************************************************************/

#include "processManager.h"
#include <fstream>

int main(int argc, char** argv) {
    //create new manager
    processManager prm = processManager();
    
    //get file from args
    std::ifstream infile;
    std::string filename = argv[1];
    
    //open file
    infile.open(filename);
    
    //starter id
    int id = 101;
    //helper strings
    std::string line1 = "";
    std::string line2 = "";
    
    //print title
    std::cout << "Simulation of CPU Scheduling\n\n";
    
    //while there are more lines, make new process and increment ID
    while(getline(infile, line1) && 
          getline(infile, line2)) {
        prm.newProcess(id, line1, line2);
        id++;
    }
    
    //load queue
    prm.loadReadyQueue();
    
    //while there is the ability to be active
    //run the manager
    while(prm.isActive()) {
        prm.run();
    }
    
    //print ending stats output
    std::cout << prm.printEnd();
    
    return 0;
}