# CSCI480

Collection of work from my Principles of Operating Systems class.

Principles and practices of modern operating system design. Includes file systems organization; memory management; multitasking; windowing interfaces; interprocess communication, including communications across a network; and client-server models of processing. Extensive laboratory work.